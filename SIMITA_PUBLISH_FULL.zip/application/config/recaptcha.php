<?php
defined('BASEPATH') OR exit('No direct script access allowed');

// To use reCAPTCHA, you need to sign up for an API key pair for your site.
// link: http://www.google.com/recaptcha/admin
$config['recaptcha_site_key'] = '6Lcv12kUAAAAALIz9xiuRQZ3g5LxGV490r_btBoj';
$config['recaptcha_secret_key'] = '6Lcv12kUAAAAAMqpmReC1KhEMlLHpwXx3IkBj1I9';

// reCAPTCHA supported 40+ languages listed here:
// https://developers.google.com/recaptcha/docs/language
$config['recaptcha_lang'] = 'en';

/* End of file recaptcha.php */
/* Location: ./application/config/recaptcha.php */
